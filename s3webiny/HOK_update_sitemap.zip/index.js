'use strict';
var AWS = require('aws-sdk');
const sRegion = process.env.AWS_REGION;
AWS.config.update({region: sRegion});
const s3 = new AWS.S3 (); 
const { XMLParser, XMLBuilder} = require('fast-xml-parser');
const parser = new XMLParser({ignoreAttributes : false,
    isArray: (name, jpath, isLeafNode, isAttribute) => { 
        if( name == "url") return true;
    }
});

console.log("xmlparser:" ,XMLParser);
const builder = new XMLBuilder({ignoreAttributes : false});

/**
 * Receives a changed html file by S3 notification and updates the "sitemap.xml" file in the same bucket accordingly.
 */
exports.handler = async (event) => {
    console.log("event:" ,JSON.stringify(event));

    var datetime = new Date();
    let sToday = datetime.toISOString().slice(0,10); 
    console.log(sToday);        
    let oNewSitemap = null;
    
    try{        
        oNewSitemap = parser.parse((await s3.getObject({
            Bucket: event.Records[0].s3.bucket.name, 
            Key: 'sitemap.xml'
        }).promise()).Body.toString("utf-8"));
    } catch(err){console.log("error while reading sitemap.xml",err);}

    let oEmptySitemap = false;
    if(oNewSitemap==null){
        oNewSitemap =   {
                            "?xml": {
                                "@_version": "1.0",
                                "@_encoding": "UTF-8"
                            },            
                            "urlset": {
                                "url": [],
                                "@_xmlns": "http://www.sitemaps.org/schemas/sitemap/0.9"
                            }
                        };
        oEmptySitemap = true;
    }

    for (let record of event.Records) {
        let sURL = "https://parenti.help/"+event.Records[0].s3.object.key;
        
        let iHit = -1;
        if( !oEmptySitemap ){
            iHit = oNewSitemap.urlset.url.findIndex(o => o.loc === sURL);
        }
        if(record.eventName.startsWith("ObjectCreated")){
            if(iHit<0){
                if( oEmptySitemap ){
                    oNewSitemap.urlset.url=[{"loc":sURL,"lastmod":sToday}];
                }else{
                    oNewSitemap.urlset.url.push({"loc":sURL,"lastmod":sToday});
                }
            } else {
                oNewSitemap.urlset.url[iHit]={"loc":sURL,"lastmod":sToday};
            }
        } else if(record.eventName.startsWith("ObjectDeleted")){
            if(iHit>=0){
                oNewSitemap.urlset.url.splice(iHit, 1);
            }
             
        } else {
            console.log("unhandeled event:",record.eventName);
        }

    }

    await s3.putObject({ 
        Body: builder.build(oNewSitemap), 
        Bucket: event.Records[0].s3.bucket.name, 
        Key: 'sitemap.xml', 
        ACL: 'public-read',  
        ContentType: 'text/html'
    }).promise();        

    return 0;
};