/**
* For each element submitted by Dynamo DB
*   check, if the element is of type "published"
*       if it is, copy it to target DynamoDB
*/

'use strict';

/** Map environment variables */
    const sRegion = process.env.AWS_REGION;	
	const sTargetTableNameStaticContent = process.env.destination_table;
	let aModels = [];
	try {
		aModels = JSON.parse(process.env.relevant_webiny_models);  
	} catch(e){}

/** Prepare AWS objects */
    import { DynamoDBClient, PutItemCommand, DeleteItemCommand, QueryCommand, ScanCommand } from "@aws-sdk/client-dynamodb";
    const ddb = new DynamoDBClient({region: sRegion});

	//const zlib = require('zlib');
	import zlib from 'zlib'; // Import zlib module
	import jsonpack from 'jsonpack'; // Import jsonpack module

//Helper
    /**
     * @function HOK_scanTable
     * 
     * Uses the "scan" command untill all data is loaded
     * 
     * @param {object} documentClient   DynamoDB Document CLient to use for scan
     * @param {object} params           Scan parameters
     * 
     * @return {array}  Array with of scan results 
     */
    async function HOK_scanTable(documentClient, params) {
        const scanResults = [];
        let items = null;
        do{
            items = await documentClient.send(new ScanCommand(params));
            items.Items.forEach((item) => scanResults.push(item));
            params.ExclusiveStartKey  = items.LastEvaluatedKey;
        }while(typeof items.LastEvaluatedKey !== "undefined");
        return scanResults;
    }

	function decompressGzip(body) {
	
	  return new Promise( function( resolve, reject ) {
			var buffer = new Buffer(body, 'base64');
			zlib.unzip(buffer, function(err, buffer2) {
			  if (!err) {
			  	resolve(buffer2.toString());
			  } else {
			  	reject;
			  } 	
			});
	  });
	
	}

	/** Returns an Object with translations of <type>@<string> (id) to contentid (as set in Webiny) fields */
	async function prepareTranslation(sWebinyTable){

		//get all model entries from DynamoDB 
    		const params = {
    			TableName:sWebinyTable,
			    FilterExpression: "#field = :val",
			    ExpressionAttributeNames: {
			        "#field": "_et",
			    },
			    ExpressionAttributeValues: { ":val": { "S": "CmsModels"} }  
    		};
    		let aModels = await HOK_scanTable(ddb,params);

		let oTranslation = [];
    		
    	//Extract fields
    		for(let i=0; i<aModels.length; i++){
    			if(aModels[i].fields != undefined){
    				if(aModels[i].fields.L != undefined){
						for(let j=0; j<aModels[i].fields.L.length; j++){
							if(aModels[i].fields.L[j].M != undefined){
								if(aModels[i].fields.L[j].M.storageId != undefined && aModels[i].fields.L[j].M.fieldId != undefined){
									if(aModels[i].fields.L[j].M.storageId.S != undefined && aModels[i].fields.L[j].M.fieldId.S != undefined){
										oTranslation[aModels[i].fields.L[j].M.storageId.S] = aModels[i].fields.L[j].M.fieldId.S;
									}									
								}
							}
						}
					}
    			}
    		}

		return oTranslation;
	}

	/** Replaces <type>@<string> (id) with contentid (as set in Webiny) fields */
	async function fixcontentids(event){
		
		if(event.Records == undefined){return event;}
	    for (let i=0; i<event.Records.length; i++){

	    	const sSourceTableName = event.Records[i].eventSourceARN.substring( event.Records[i].eventSourceARN.indexOf(":table/")+7  ,  event.Records[i].eventSourceARN.indexOf("/stream") );
			let oTranslation = await prepareTranslation( sSourceTableName );

	    	let aImages = [];
			if (event.Records[i].dynamodb.OldImage != undefined){aImages.push("OldImage");}
			if (event.Records[i].dynamodb.NewImage != undefined){aImages.push("NewImage");}
	
		    for (let j=0; j<aImages.length; j++){
		    	if (event.Records[i].dynamodb[aImages[j]].values != undefined){
			    	if (event.Records[i].dynamodb[aImages[j]].values.M != undefined){
			    		let aKeys = Object.keys(event.Records[i].dynamodb[aImages[j]].values.M);
		    			for (let k=0; k<aKeys.length; k++){		    		
		    				event.Records[i].dynamodb[aImages[j]].values.M[oTranslation[aKeys[k]]] = event.Records[i].dynamodb[aImages[j]].values.M[aKeys[k]];
		    				if (oTranslation[aKeys[k]] != aKeys[k]) {
		    					delete event.Records[i].dynamodb[aImages[j]].values.M[aKeys[k]];		    					
		    				}
		    			}
			    	}	    	
		    	}
		    } 
	    }

	    return event;
	} 

export const handler = async (event) => {

	if(event == undefined){return null;}

	console.log("event:" ,JSON.stringify(event));

	aModels.push("staticCodeContent");
	aModels.push("staticContent");

	event = await fixcontentids(event);

	function jsonToHtml(json){

		let html = "";
		if(json?.root?.type == 'root'){
			html += jsonToHtml(json.root.children);
		}		
		for(let i=0;i<json.length;i++){
			if(json[i].type == 'paragraph-element'){
console.log('json[i]:', json[i]);
				html += "<p ";
				if( json[i].format != undefined ){
					html += "style='text-align:"+json[i].format+";' ";					
				}
				if( json[i].className != undefined ){
					html += "class='"+json[i].className+"' ";
				}
				html += ">";
				if(json[i].children!=undefined) { html += jsonToHtml(json[i].children); }
				html += "</p>";
			} else if(json[i].type == 'text'){
				
				switch (json[i].format) {
				  case 0:
				    html += json[i].text;
				    break;
				  case 1:
				    html += "<b>"+json[i].text+"</b>";
				    break;				    
				  case 2:
				    html += "<i>"+json[i].text+"</i>";
				    break;
				  case 3:
				    html += "<b><i>"+json[i].text+"</i><b>";
				    break;				    
				  case 8:
				    html += "<u>"+json[i].text+"</u>";
				    break;
				  case 9:
				    html += "<b><u>"+json[i].text+"</u></b>";
				    break;
				  case 11:
				    html += "<i><b><u>"+json[i].text+"</u></b></i>";
				    break;
				}
			} else if(json[i].type == 'image'){
				html += "<figure>";
				html += "<img src='"+json[i].src+"'>";
				if(json[i].showCaption){
    				html += "<figcaption>"+jsonToHtml(json[i].caption.editorState.root.children)+"</figcaption>";
				}
				html += "</figure>";
			} else if(json[i].type == 'delimiter'){
				html += "<hr>";
			} else if(json[i].type == 'linebreak'){
				html += "<br>";
			} else if(json[i].type == 'heading-element'){
				html += "<"+json[i].tag+" ";
				if( json[i].format != undefined ){
					html += "style='text-align:"+json[i].format+";' ";					
				}
				if( json[i].className != undefined ){
					html += "class='"+json[i].className+"' ";
				}
				html += "'>";
				html += jsonToHtml(json[i].children)+" ";
				html += "</"+json[i].tag+">";
			} else if(json[i].type == 'webiny-list'){
				if(json[i].listType=="number"){
					html += "<ol>";
				} else {
					html += "<ul>";					
				}
				html += jsonToHtml(json[i].children);
				if(json[i].listType=="number"){
					html += "</ol>";
				} else {
					html += "</ul>";
				}				
			} else if(json[i].type == 'webiny-listitem'){
				html += "<li>";
				html += jsonToHtml(json[i].children);
				html += "</li>";				
			} else if(json[i].type == 'link'){
				html += '<a href="' + json[i].url + '"'
				if(json[i].target!=null){
					html += ' target="'+json[i].target+'" ';
				}
				if( json[i].format != undefined ){
					html += " style='text-align:"+json[i].format+";' ";					
				}	
				html += '>';
				html += jsonToHtml(json[i].children);
				html += '</a>';
			} else {
				console.warn('HTML ELement not supported:', json[i].type);
			}
			// More content types
		}
		return (html);
	}

	if(event.Records == undefined){return null;}

    for (let i=0; i<event.Records.length; i++){

        //For each record
	    	if(event.Records[i] == undefined){return null;}        
        	if(event.Records[i].eventName == "REMOVE"){ //If entry is removed -> remove
                //delete from target DynamoDB 
                    const oParams = {
                      TableName: sTargetTableNameStaticContent,
                      Key: {
				        'id': {
				            "S" : event.Records[i].dynamodb.Keys.PK.S.split("#").pop()
				         }                      	
                      }
                    };
                    await ddb.send(new DeleteItemCommand(oParams));
        	} else { //else check if it is a published record
            	if(event.Records[i]?.dynamodb?.NewImage?.status?.S == 'published'){
            		if( aModels.includes(event.Records[i].dynamodb.NewImage.modelId.S) ){ 
                        let sTweakedRecordId = event.Records[i].dynamodb.NewImage.id.S;
						const iCutOf = sTweakedRecordId.lastIndexOf("#")
						sTweakedRecordId = sTweakedRecordId.substring(0, iCutOf);
						let sContentId = event.Records[i].dynamodb.NewImage.values.M.contentid;
						if(sContentId==undefined){sContentId = {"S": sTweakedRecordId}}
                        const params = {
                          TableName: sTargetTableNameStaticContent,
                          Item: {
                            'id' : {"S": sTweakedRecordId},
                            'contentid' : sContentId,
                            'updatedAt' : event.Records[i].dynamodb.NewImage.savedOn,
                            'createdAt' : event.Records[i].dynamodb.NewImage.createdOn,                                
							'__typename': event.Records[i].dynamodb.NewImage.modelId,
							'_lastChangedAt': {"N": event.Records[i].dynamodb.ApproximateCreationDateTime.toString()},
							"_version": event.Records[i].dynamodb.NewImage.version
                          }
                        }; 
                        
                        //Reformat content
						const oValueObject = event.Records[i].dynamodb.NewImage.values.M;
						for (const [sKey, oValue] of Object.entries(event.Records[i].dynamodb.NewImage.values.M)) {
							if(oValue.M !== undefined){
								if(oValue.M.compression.S=="gzip"){
									oValue.S = await decompressGzip(oValue.M.value.S);
									delete oValue.M;									
								} else if(oValue.M.compression.S=="jsonpack") {
									if(oValue.M.value.NULL===undefined){
										oValue.S = jsonToHtml( jsonpack.unpack(oValue.M.value.S) );
									}
									delete oValue.M;									
								}
							}
							if(oValue.S !== undefined || oValue.L !== undefined  || oValue.N !== undefined || oValue.BOOL !== undefined) {
								params.Item[sKey]= oValue;
							}
						}
						
                        await ddb.send(new PutItemCommand(params));
                    }

            	} else {return null;}
        	}
    } 
    
    return true;
};
