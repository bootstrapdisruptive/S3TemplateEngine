'use strict';
/**
 * @lambda "<ENV>_HOK_transfer_published_item
 * 
 * For each element submitted by Dynamo DB check, if the element is of type
 * "published" and belongs to a relevant modell. If it is, copy it to target
 * DynamoDB.
 * 
 * @param event <object> 
 * 
 * @return true or error object
 */

/** Map enbvironment variables */
	const sTargetTableName = process.env.destination_table;
	const aWebinyModels = process.env.relevant_webiny_models.split(",");

/** Prepare AWS objects */
	const AWS = require('aws-sdk');
	const ddb = new AWS.DynamoDB();
	const jsonpack = require('jsonpack.js');
	const zlib = require('zlib');


/** Main handler. 
  * Lamnbda builds a new environment and invokes new calls into htis environment
  * for a certain, not predictable, time. In that case everything outside of
  * this handler will persist. This is OK for cosntants, but ends up 
  * unpredictable for gobal variables and (under certain cirsumstances) for
  * variables in helper functions.
  * Therefore, helper functions are part of this main handler, so they are
  * initialized freshly and behave predictable on each call of the lambda.
  */
exports.handler = async (event) => {
    console.log("event:" ,JSON.stringify(event)); //For error debugging: push event to CloudWatch

    /** Helper */
		function jsonToHtml(json){
			let html = "";
			for(let i=0;i<json.length;i++){
				if(json[i].type == 'paragraph'){
					html += "<p style='textAlign:"+json[i].data.textAlign+";' class='"+json[i].data.className+"'>"+json[i].data.text+"</p>";
				} else if(json[i].type == 'delimiter'){
					html += "<hr>";
				} else if(json[i].type == 'image'){
					html += "<figure>";
					html += "<img src='"+json[i].data.file+"'>";
	    			html += "<figcaption>"+json[i].data.caption+"</figcaption>";
					html += "</figure>";
				} else if(json[i].type == 'header'){
					html += "<h"+json[i].data.level+" style='textAlign:"+json[i].data.textAlign+"'; class='"+json[i].data.className+"'>";
					html += json[i].data.text;
					html += "</h"+json[i].data.level+">";
				} else if(json[i].type == 'list'){
					if(json[i].data.style=="ordered"){
						html += "<ol>";
					} else {
						html += "<ul>";					
					}
					for(let j=0; j<json[i].data.items.length; j++){
						html += "<li>"+json[i].data.items[j]+"</li>";
					}
					if(json[i].data.style=="ordered"){
						html += "</ol>";
					} else {
						html += "</ul>";
					}				
				} else if(json[i].type == 'quote'){
					html += "<blockquote>";
					html += "<p style='textAlign:"+json[i].data.alignment+";'>"+json[i].data.text+"</p>";
					html += "</blockquote>";
				}  
				/* More content types */
			}
			return (html);
		}
	
    /** "MAIN" */
		if(event.Records == undefined){return null;}
	
		aWebinyModels.push("staticContent");
		aWebinyModels.push("staticCodeContent");
	
	    for (let i=0; i<event.Records.length; i++){
	        //For each record
		    	if(event.Records[i] == undefined){return null;}        
	        	if(event.Records[i].eventName == "REMOVE"){//If entry is removed -> remove
	                //delete from target DynamoDB 
	                    const params = {
	                      TableName: sTargetTableName,
	                      Key: {
					        'id': {
					            "S" : event.Records[i].dynamodb.Keys.PK.S.split("#").pop()
					         }                      	
	                      }
	                    };   
	                    await ddb.deleteItem(params).promise();
	
	        	} else { //else check if it is a published record
		        	if(event.Records[i].dynamodb == undefined){return null;}
		        	if(event.Records[i].dynamodb.NewImage == undefined){return null;}
		        	if(event.Records[i].dynamodb.NewImage.status == undefined){return null;}
	            	if(event.Records[i].dynamodb.NewImage.status.S == 'published'){
	                    if( aWebinyModels.includes(event.Records[i].dynamodb.NewImage.modelId.S)){ //Check if modelID is ARTIKEL
							//Reformat content
								for (const [key, value] of Object.entries(event.Records[i].dynamodb.NewImage.values.M)) {
									if(value.M != undefined){
										if(value.M.compression != undefined){		
											if(value.M.compression != undefined){
												if(value.M.compression.S != undefined){
													if(value.M.compression.S == "jsonpack"){
														event.Records[i].dynamodb.NewImage.values.M[key] = {"S": await jsonToHtml( jsonpack.unpack(value.M.value.S) )};
													}
													if(value.M.compression.S=="gzip"){
														event.Records[i].dynamodb.NewImage.values.M[key] = {"S": await decompressGzip(value.M.value.S)};
													}												
												}
											}			
										}
									}
								}
								
							//Move Meta Data into content
	                            event.Records[i].dynamodb.NewImage.values.M.id = event.Records[i].dynamodb.NewImage.entryId;
	                            event.Records[i].dynamodb.NewImage.values.M.updatedAt = event.Records[i].dynamodb.NewImage.savedOn;
	                            event.Records[i].dynamodb.NewImage.values.M.createdAt = event.Records[i].dynamodb.NewImage.createdOn;
								event.Records[i].dynamodb.NewImage.values.M.__typename= event.Records[i].dynamodb.NewImage.modelId;
								event.Records[i].dynamodb.NewImage.values.M._lastChangedAt= {"N": event.Records[i].dynamodb.ApproximateCreationDateTime.toString()};
								event.Records[i].dynamodb.NewImage.values.M._version= event.Records[i].dynamodb.NewImage.version;
							
	                        //copy content to target DynamoDB 
	                            const params = {
	                              TableName: sTargetTableName,
	                              Item: event.Records[i].dynamodb.NewImage.values.M
	                            };   
	                            
	                            await ddb.putItem(params, function(err, data) {
	                              if (err) {
	                                console.warn("EWrror in ddb.putItem with:",params,err);
	                                throw(err);
	                              }
	                            }).promise();
	                            
	                    }
	            	}
	        	}
	    }
	    
    return true;
};

function decompressGzip(body) {

  return new Promise( function( resolve, reject ) {
		var buffer = new Buffer(body, 'base64');
		zlib.unzip(buffer, function(err, buffer2) {
		  if (!err) {
		  	resolve(buffer2.toString());
		  } else {
		  	reject;
		  } 	
		});
  });

}