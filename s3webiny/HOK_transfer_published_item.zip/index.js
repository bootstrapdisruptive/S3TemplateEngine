/**
* For each element submitted by Dynamo DB
*   check, if the element is of type "published"
*       if it is, copy it to target DynamoDB
*/

'use strict';
var AWS = require('aws-sdk');
var jsonpack = require('jsonpack.js');
const ddb = new AWS.DynamoDB();
const sTargetTableNameStaticContent = process.env.destination_table;
const aModels = JSON.parse(process.env.relevant_webiny_models);
const zlib = require('zlib');

//Helper

    async function scanTable(documentClient, params) {
        const scanResults = [];
        let items = null;
        do{
            items =  await documentClient.scan(params).promise();
            items.Items.forEach((item) => scanResults.push(item));
            params.ExclusiveStartKey  = items.LastEvaluatedKey;
        }while(typeof items.LastEvaluatedKey !== "undefined");
        
        return scanResults;
    };

	function decompressGzip(body) {
	
	  return new Promise( function( resolve, reject ) {
			var buffer = new Buffer(body, 'base64');
			zlib.unzip(buffer, function(err, buffer2) {
			  if (!err) {
			  	resolve(buffer2.toString());
			  } else {
			  	reject;
			  } 	
			});
	  });
	
	}

	/** Returns an Object with translations of <type>@<string> (id) to contentid (as set in Webiny) fields */
	async function prepareTranslation(sWebinyTable){

		//get all model entries from DynamoDB 
    		const params = {
    			TableName:sWebinyTable,
			    FilterExpression: "#field = :val",
			    ExpressionAttributeNames: {
			        "#field": "_et",
			    },
			    ExpressionAttributeValues: { ":val": { "S": "CmsModels"} }  
    		};
    		let aModels = await scanTable(ddb,params);

		let oTranslation = [];
    		
    	//Extract fields
    		for(let i=0; i<aModels.length; i++){
    			if(aModels[i].fields != undefined){
    				if(aModels[i].fields.L != undefined){
						for(let j=0; j<aModels[i].fields.L.length; j++){
							if(aModels[i].fields.L[j].M != undefined){
								if(aModels[i].fields.L[j].M.storageId != undefined && aModels[i].fields.L[j].M.fieldId != undefined){
									if(aModels[i].fields.L[j].M.storageId.S != undefined && aModels[i].fields.L[j].M.fieldId.S != undefined){
										oTranslation[aModels[i].fields.L[j].M.storageId.S] = aModels[i].fields.L[j].M.fieldId.S;
									}									
								}
							}
						}
					}
    			}
    		}

		return oTranslation;
	}
	
	/** Replaces <type>@<string> (id) with contentid (as set in Webiny) fields */
	async function fixcontentids(event){
		
		if(event.Records == undefined){return event;}
	    for (let i=0; i<event.Records.length; i++){

	    	const sSourceTableName = event.Records[i].eventSourceARN.substring( event.Records[i].eventSourceARN.indexOf(":table/")+7  ,  event.Records[i].eventSourceARN.indexOf("/stream") );
			let oTranslation = await prepareTranslation( sSourceTableName );

	    	let aImages = [];
			if (event.Records[i].dynamodb.OldImage != undefined){aImages.push("OldImage");}
			if (event.Records[i].dynamodb.NewImage != undefined){aImages.push("NewImage");}
	
		    for (let j=0; j<aImages.length; j++){
		    	if (event.Records[i].dynamodb[aImages[j]].values != undefined){
			    	if (event.Records[i].dynamodb[aImages[j]].values.M != undefined){
			    		let aKeys = Object.keys(event.Records[i].dynamodb[aImages[j]].values.M);
		    			for (let k=0; k<aKeys.length; k++){		    		
		    				event.Records[i].dynamodb[aImages[j]].values.M[oTranslation[aKeys[k]]] = event.Records[i].dynamodb[aImages[j]].values.M[aKeys[k]];
		    				if (oTranslation[aKeys[k]] != aKeys[k]) {
		    					delete event.Records[i].dynamodb[aImages[j]].values.M[aKeys[k]];		    					
		    				}
		    			}
			    	}	    	
		    	}
		    } 
	    }

	    return event;
	} 

exports.handler = async (event) => {

	if(event == undefined){return null;}

	console.log("event:" ,JSON.stringify(event));

	aModels.push("staticCodeContent");
	aModels.push("staticContent");
	event = await fixcontentids(event);

	function jsonToHtml(json){
		let html = "";
		for(let i=0;i<json.length;i++){
			if(json[i].type == 'paragraph'){
				html += "<p style='text-align:"+json[i].data.textAlign+";' class='"+json[i].data.className+"'>"+json[i].data.text+"</p>";
			} else if(json[i].type == 'delimiter'){
				html += "<hr>";
			} else if(json[i].type == 'image'){
				html += "<figure>";
				html += "<img src='"+json[i].data.file+"'>";
    			html += "<figcaption>"+json[i].data.caption+"</figcaption>";
				html += "</figure>";
			} else if(json[i].type == 'header'){
				html += "<h"+json[i].data.level+" style='text-align:"+json[i].data.textAlign+"'; class='"+json[i].data.className+"'>";
				html += json[i].data.text;
				html += "</h"+json[i].data.level+">";
			} else if(json[i].type == 'list'){
				if(json[i].data.style=="ordered"){
					html += "<ol>";
				} else {
					html += "<ul>";					
				}
				for(let j=0; j<json[i].data.items.length; j++){
					html += "<li>"+json[i].data.items[j]+"</li>";
				}
				if(json[i].data.style=="ordered"){
					html += "</ol>";
				} else {
					html += "</ul>";
				}				
			} else if(json[i].type == 'quote'){
				html += "<blockquote>";
				html += "<p style='text-align:"+json[i].data.alignment+";'>"+json[i].data.text+"</p>";
				html += "</blockquote>";
			}  
			// More content types
		}
		return (html);
	}

	if(event.Records == undefined){return null;}

    for (let i=0; i<event.Records.length; i++){

        //For each record
	    	if(event.Records[i] == undefined){return null;}        
        	if(event.Records[i].eventName == "REMOVE"){//If entry is removed -> remove
                //delete from target DynamoDB 
                    const params = {
                      TableName: sTargetTableNameStaticContent,
                      Key: {
				        'id': {
				            "S" : event.Records[i].dynamodb.Keys.PK.S.split("#").pop()
				         }                      	
                      }
                    };   
                    await ddb.deleteItem(params).promise();

        	} else { //else check if it is a published record
	        	if(event.Records[i].dynamodb == undefined){return null;}
	        	if(event.Records[i].dynamodb.NewImage == undefined){return null;}
	        	if(event.Records[i].dynamodb.NewImage.status == undefined){return null;}
            	if(event.Records[i].dynamodb.NewImage.status.S == 'published'){
            		if( aModels.includes(event.Records[i].dynamodb.NewImage.modelId.S) ){ 
                        
                        let sTweakedRecordId = event.Records[i].dynamodb.NewImage.id.S;
						const iCutOf = sTweakedRecordId.lastIndexOf("#")
						sTweakedRecordId = sTweakedRecordId.substring(0, iCutOf);
                        const params = {
                          TableName: sTargetTableNameStaticContent,
                          Item: {
                            'id' : {"S": sTweakedRecordId},
                            'contentid' : event.Records[i].dynamodb.NewImage.values.M.contentid,
                            'updatedAt' : event.Records[i].dynamodb.NewImage.savedOn,
                            'createdAt' : event.Records[i].dynamodb.NewImage.createdOn,                                
							'__typename': event.Records[i].dynamodb.NewImage.modelId,
							'_lastChangedAt': {"N": event.Records[i].dynamodb.ApproximateCreationDateTime.toString()},
							"_version": event.Records[i].dynamodb.NewImage.version
                          }
                        }; 
                        
                        //Reformat content
						const oValueObject = event.Records[i].dynamodb.NewImage.values.M;
						for (const [sKey, oValue] of Object.entries(event.Records[i].dynamodb.NewImage.values.M)) {
							if(oValue.M != undefined){
								if(oValue.M.compression.S=="gzip"){
									oValue.S = await decompressGzip(oValue.M.value.S);
									delete oValue.M;									
								} else if(oValue.M.compression.S=="jsonpack") {
									oValue.S = jsonToHtml( jsonpack.unpack(oValue.M.value.S) );
									delete oValue.M;
								}
							}
							params.Item[sKey]= oValue;
						}

                        await ddb.putItem(params, function(err, data) {
                          if (err) {
                            console.warn(err.message);
                          }
                        }).promise();
                    }

            	}
        	}
    }
    
    return true;
};
