/**
* For each element submitted by Dynamo DB
*   check, if the element is of type "published"
*       if it is, copy it to target DynamoDB
*/

'use strict';
var AWS = require('aws-sdk');
var jsonpack = require('jsonpack.js');
const ddb = new AWS.DynamoDB();
const sTargetTableName = process.env.destination_table;
const sTargetTableNameStaticContent = process.env.destination_table_staticContent;
const aWebinyModels = process.env.relevant_webiny_models.split(",");

const zlib = require('zlib');

exports.handler = async (event) => {

	if(event == undefined){return null;}

console.log("event:" ,JSON.stringify(event));

	function jsonToHtml(json){
		let html = "";
		for(let i=0;i<json.length;i++){
			if(json[i].type == 'paragraph'){
				html += "<p style='textAlign:"+json[i].data.textAlign+";' class='"+json[i].data.className+"'>"+json[i].data.text+"</p>";
			} else if(json[i].type == 'delimiter'){
				html += "<hr>";
			} else if(json[i].type == 'image'){
				html += "<figure>";
				html += "<img src='"+json[i].data.file+"'>";
    			html += "<figcaption>"+json[i].data.caption+"</figcaption>";
				html += "</figure>";
			} else if(json[i].type == 'header'){
				html += "<h"+json[i].data.level+" style='textAlign:"+json[i].data.textAlign+"'; class='"+json[i].data.className+"'>";
				html += json[i].data.text;
				html += "</h"+json[i].data.level+">";
			} else if(json[i].type == 'list'){
				if(json[i].data.style=="ordered"){
					html += "<ol>";
				} else {
					html += "<ul>";					
				}
				for(let j=0; j<json[i].data.items.length; j++){
					html += "<li>"+json[i].data.items[j]+"</li>";
				}
				if(json[i].data.style=="ordered"){
					html += "</ol>";
				} else {
					html += "</ul>";
				}				
			} else if(json[i].type == 'quote'){
				html += "<blockquote>";
				html += "<p style='textAlign:"+json[i].data.alignment+";'>"+json[i].data.text+"</p>";
				html += "</blockquote>";
			}  
			/* More content types */
		}
		return (html);
	}

	if(event.Records == undefined){return null;}

    for (let i=0; i<event.Records.length; i++){
        //For each record
	    	if(event.Records[i] == undefined){return null;}        
        	if(event.Records[i].eventName == "REMOVE"){//If entry is removed -> remove
                //delete from target DynamoDB 
                    const params = {
                      TableName: sTargetTableName,
                      Key: {
				        'id': {
				            "S" : event.Records[i].dynamodb.Keys.PK.S.split("#").pop()
				         }                      	
                      }
                    };   
                    await ddb.deleteItem(params).promise();

        	} else { //else check if it is a published record
	        	if(event.Records[i].dynamodb == undefined){return null;}
	        	if(event.Records[i].dynamodb.NewImage == undefined){return null;}
	        	if(event.Records[i].dynamodb.NewImage.status == undefined){return null;}
            	if(event.Records[i].dynamodb.NewImage.status.S == 'published'){
                    if( aWebinyModels.includes(event.Records[i].dynamodb.NewImage.modelId.S)){ //Check if modelID is ARTIKEL
						//Reformat content
							for (const [key, value] of Object.entries(event.Records[i].dynamodb.NewImage.values.M)) {
								if(value.M != undefined){
									if(value.M.compression != undefined){		
										if(value.M.compression != undefined){
											if(value.M.compression.S != undefined){
												if(value.M.compression.S == "jsonpack"){
													event.Records[i].dynamodb.NewImage.values.M[key] = {"S": jsonToHtml( jsonpack.unpack(value.M.value.S) )};
												}
											}
										}			
									}
								}
							}
							
						//Move Meta Data into content
                            event.Records[i].dynamodb.NewImage.values.M.id = event.Records[i].dynamodb.NewImage.entryId;
                            event.Records[i].dynamodb.NewImage.values.M.updatedAt = event.Records[i].dynamodb.NewImage.savedOn;
                            event.Records[i].dynamodb.NewImage.values.M.createdAt = event.Records[i].dynamodb.NewImage.createdOn;
							event.Records[i].dynamodb.NewImage.values.M.__typename= event.Records[i].dynamodb.NewImage.modelId;
							event.Records[i].dynamodb.NewImage.values.M._lastChangedAt= {"N": event.Records[i].dynamodb.ApproximateCreationDateTime.toString()};
							event.Records[i].dynamodb.NewImage.values.M._version= event.Records[i].dynamodb.NewImage.version;
						
                        //copy content to target DynamoDB 
                            const params = {
                              TableName: sTargetTableName,
                              Item: event.Records[i].dynamodb.NewImage.values.M
                            };   
                            await ddb.putItem(params, function(err, data) {
                              if (err) {
                                console.warn(err.message);
                              }
                            }).promise();
                            
                    } else if(event.Records[i].dynamodb.NewImage.modelId.S=="staticContent"){ 
											//Reformat content
											let html = "";
											
											if(event.Records[i].dynamodb.NewImage.values.M.content != undefined){

												if(event.Records[i].dynamodb.NewImage.values.M.content.M.value.S!=undefined){
													html = jsonToHtml( jsonpack.unpack(event.Records[i].dynamodb.NewImage.values.M.content.M.value.S) );							

												//copy to target DynamoDB 
							
															let contentID = "";
															if(event.Records[i].dynamodb.NewImage.values.M.contentId != undefined){
																contentID = event.Records[i].dynamodb.NewImage.values.M.contentId;
															} else {
																contentID = event.Records[i].dynamodb.NewImage.values.M.contentid;
															}
	                            const params = {
	                              TableName: sTargetTableNameStaticContent,
	                              Item: {
	                                'content_id' : contentID,
	                                'updatedAt' : event.Records[i].dynamodb.NewImage.savedOn,
	                                'createdAt' : event.Records[i].dynamodb.NewImage.createdOn,                                
									'__typename': event.Records[i].dynamodb.NewImage.modelId,
									'_lastChangedAt': {"N": event.Records[i].dynamodb.ApproximateCreationDateTime.toString()},
									"_version": event.Records[i].dynamodb.NewImage.version,
	                                'content' : {'S' : html},
	                              }
	                            };   
	                            await ddb.putItem(params, function(err, data) {
	                              if (err) {
	                                console.warn(err.message);
	                              }
	                            }).promise();
	                            
													}                            
                            
											}                            
                    } else if(event.Records[i].dynamodb.NewImage.modelId.S=="staticCodeContent"){ 
	                            //Reformat content
									let html = "";
									if(event.Records[i].dynamodb.NewImage.values.M.content.M.compression.S=="gzip"){
										html = await decompressGzip(event.Records[i].dynamodb.NewImage.values.M.content.M.value.S);
									}

	                            const params = {
	                              TableName: sTargetTableNameStaticContent,
	                              Item: {
	                                'content_id' : event.Records[i].dynamodb.NewImage.values.M.contentId,
	                                'updatedAt' : event.Records[i].dynamodb.NewImage.savedOn,
	                                'createdAt' : event.Records[i].dynamodb.NewImage.createdOn,                                
									'__typename': event.Records[i].dynamodb.NewImage.modelId,
									'_lastChangedAt': {"N": event.Records[i].dynamodb.ApproximateCreationDateTime.toString()},
									"_version": event.Records[i].dynamodb.NewImage.version,
	                                'content' : {'S' : html},
	                              }
	                            };   
//console.log(" event.Records[i].dynamodb.NewImage:" , event.Records[i].dynamodb.NewImage);
//console.log(params);	                            
	                            await ddb.putItem(params, function(err, data) {
	                              if (err) {
	                                console.warn(err.message);
	                              }
	                            }).promise();
	                            
                    }
                    
            	}
        	}
    }
    return true;
};

function decompressGzip(body) {

  return new Promise( function( resolve, reject ) {
		var buffer = new Buffer(body, 'base64');
		zlib.unzip(buffer, function(err, buffer2) {
		  if (!err) {
		  	resolve(buffer2.toString());
		  } else {
		  	reject;
		  } 	
		});
  });

}