'use strict';

/** Map environment variables */
const sRegion = process.env.AWS_REGION;
const sTable = process.env.last_update_counter_table;
const sStepFunctionArn = process.env.step_function_arn;

/** Prepare AWS objects */
    import { DynamoDBClient, PutItemCommand } from "@aws-sdk/client-dynamodb";
    const ddb = new DynamoDBClient({region: sRegion});

    import { SFNClient, StartExecutionCommand } from "@aws-sdk/client-sfn";
    const sfn = new SFNClient({ region: sRegion });

async function HOK_writeTiimestamp(){
  //write current timestamp to target DynamoDB       
      let oParams = {
        TableName: sTable,
        Item: {
            "Timestamp":{"S": new Date()}
        }
      };   
      await ddb.send(new PutItemCommand(oParams)).catch((err) =>{console.warn("Error", err);});          
  return 0;
}
        
export const handler = async (event) => {
  console.log(JSON.stringify(event));
  
  await HOK_writeTiimestamp();

  try {
    const params = {
      stateMachineArn: sStepFunctionArn,
      input: JSON.stringify(event),
    };
    const result = await sfn.send(new StartExecutionCommand(params));
    console.log('Step Function started:', result);
  } catch (error) {
    console.error('Error starting Step Function:', error);
  }

  const response = {
    statusCode: 200,
    body: JSON.stringify('OK'),
  };
  return response;
};
