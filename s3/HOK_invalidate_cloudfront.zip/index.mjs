'use strict';

/** Map environment variables */
const sRegion = process.env.AWS_REGION;
const sTable = process.env.last_update_counter_table;
const sAlias = process.env.cfAliases;

/** Prepare AWS objects */
import {
  DynamoDBClient,
  ScanCommand,
  DeleteItemCommand
} from "@aws-sdk/client-dynamodb";
const ddb = new DynamoDBClient({ region: sRegion });

import {
  CloudFrontClient,
  ListDistributionsCommand,  
  CreateInvalidationCommand
} from "@aws-sdk/client-cloudfront";
const cf = new CloudFrontClient({ region: sRegion });

const MY_DISTRIBUTION_ID = "E123456789XYZ";

// Helper function to parse a DynamoDB string timestamp.
// Returns a JS Date object, or NaN if invalid.
function parseTimestamp(dynamoDBDateStr) {
  return new Date(dynamoDBDateStr);
}

// Check if older than 60s
function isOlderThan60Seconds(dateObj) {
  const diffMs = Date.now() - dateObj.getTime();
  return diffMs > 60000; // 60,000 ms in 60 seconds
}

// Delete a single item by its Timestamp key
async function deleteItemByTimestamp(timestamp) {
  await ddb.send(new DeleteItemCommand({
    TableName: sTable,
    Key: { Timestamp: { S: timestamp } },
  }));
}

// Query CloudFront to find the distribution ID by alias
async function findDistributionIdByAlias(alias) {
  console.log(`Looking up distribution for alias: ${alias}`);
  if (!alias) {
    throw new Error('CLOUDFRONT_ALIAS is not defined or is empty.');
  }

  // List all distributions
  const result = await cf.send(new ListDistributionsCommand({}));

  // If there are no distributions at all
  if (!result.DistributionList || !result.DistributionList.Items) {
    throw new Error('No CloudFront distributions found in your account.');
  }

  // Look for a distribution that has this alias
  for (const dist of result.DistributionList.Items) {
    if (dist.Aliases && dist.Aliases.Items && dist.Aliases.Items.includes(alias)) {
      console.log(`Found distributionId: ${dist.Id} for alias: ${alias}`);
      return dist.Id;
    }
  }

  // If none matched
  throw new Error(`No distribution found containing alias: ${alias}`);
}

// Create a CloudFront invalidation for "/*"
async function createCloudFrontInvalidation() {
  // 1) Find distribution by alias
  const distributionId = await findDistributionIdByAlias(sAlias);

  // 2) Create the invalidation
  const nowStr = Date.now().toString();
  const params = {
    DistributionId: distributionId,
    InvalidationBatch: {
      CallerReference: nowStr, // must be unique each time
      Paths: {
        Quantity: 1,
        Items: ['/*']
      }
    }
  };
  await cf.send(new CreateInvalidationCommand(params));
  console.log(`CloudFront invalidation created for distribution: ${distributionId}`);
}

// Delete all items in the table
async function deleteAllItemsInTable() {
  // For safety, do a *new* scan to get items currently in the table
  const scanData = await ddb.send(new ScanCommand({ TableName: sTable }));
  if (!scanData.Items || scanData.Items.length === 0) return; // nothing to delete

  for (const item of scanData.Items) {
    const tsStr = item.Timestamp?.S;
    if (tsStr) {
      await deleteItemByTimestamp(tsStr);
    }
  }
}

export const handler = async (event) => {
  console.log(JSON.stringify(event));

  // 1) Check if table is empty
  let scanResult = await ddb.send(new ScanCommand({ TableName: sTable }));
  if (!scanResult.Items || scanResult.Items.length === 0) {
    console.log("DynamoDB table is empty; no action needed.");
    return { statusCode: 200, body: JSON.stringify('OK - table empty') };
  }

  // 2) Delete everything older than 60 seconds
  for (const item of scanResult.Items) {
    const tsStr = item.Timestamp?.S;
    if (!tsStr) continue; // skip if missing
    const dateObj = parseTimestamp(tsStr);

    if (isNaN(dateObj.getTime())) {
      console.warn(`Invalid date found in item Timestamp: ${tsStr}`);
      continue;
    }
    if (isOlderThan60Seconds(dateObj)) {
      console.log(`Deleting old timestamp: ${tsStr}`);
      await deleteItemByTimestamp(tsStr);
    }
  }

  // Refresh the list after deleting old items
  scanResult = await ddb.send(new ScanCommand({ TableName: sTable }));
  const itemCount = scanResult.Items?.length || 0;

  // 3) If the DDB table has more than one entry => Step 4a
  //    else => Step 4b
  if (itemCount > 1) {
    // 4a) Delete the oldest timestamp, then end
    console.log("More than 1 item in table; removing oldest single item...");
    // Sort items by date ascending
    const sorted = scanResult.Items.slice().sort((a, b) => {
      const da = new Date(a.Timestamp.S);
      const db = new Date(b.Timestamp.S);
      return da - db; // oldest first
    });
    const oldestTs = sorted[0].Timestamp.S;
    await deleteItemByTimestamp(oldestTs);
    console.log(`Deleted oldest item: ${oldestTs}`);
    return { statusCode: 200, body: JSON.stringify('OK - oldest item removed') };

  } else {
    // itemCount <= 1
    // 4b) Create new CloudFront invalidation, then proceed with 5
    console.log("Only 1 item in table; creating CloudFront invalidation...");
    await createCloudFrontInvalidation();
    // 5) Delete all entries
    console.log("Deleting all items in table...");
    await deleteAllItemsInTable();
    console.log("All items removed. Done.");
    return { statusCode: 200, body: JSON.stringify('OK - invalidation & table cleared') };
  }
  
};
