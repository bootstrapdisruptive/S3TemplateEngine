'use strict';
var AWS = require('aws-sdk');
const sRegion = process.env.AWS_REGION;
const sDestBucket = process.env.destination_bucket;
const htmlPartElementTable = process.env.html_part_element_table;
const websiteElementTable = process.env.website_element_table;
const sOriginBucket = process.env.origin_bucket;
AWS.config.update({region: sRegion});
const s3 = new AWS.S3 (); 
const ddb = new AWS.DynamoDB();

exports.handler = async (event) => {

//Helper
    var oReplacementStore = {};
    var aReplacementShortList = [];    
    async function getReplacementHTML(replacementHTML, SourceBucket){
        aReplacementShortList.push(replacementHTML); 
            if(typeof (oReplacementStore[replacementHTML]) == "undefined"){       
                const paramsReplace = { Bucket: SourceBucket, Key: 'part/'+replacementHTML };
                try{
                    const newData = await s3.getObject(paramsReplace).promise();     
                    oReplacementStore[replacementHTML]= newData.Body.toString("utf-8");
                }catch(err){
                    console.log("error in 'getReplacementHTML' with params:");
                    console.log(paramsReplace);
                    console.log(err);
                    throw(err);                    
                }
            }
        
        return(oReplacementStore[replacementHTML]);
    }
    
    async function getReplacementHTMLfromDB(replacementHTML){
        aReplacementShortList.push(replacementHTML); 
            if(typeof (oReplacementStore[replacementHTML]) == "undefined"){     
        		const params = {
                   Key: { 
                       content_id: {S: replacementHTML}
                   },
                   TableName:websiteElementTable
        		};
                try{
                    const oData = await ddb.getItem(params).promise();
                    if(oData.Item!=undefined){
                        oReplacementStore[replacementHTML]= oData.Item.content.S;                        
                    }
                }catch(err){
                    console.log("error in 'getReplacementHTMLfromDB' with params:");
                    console.log(params);
                    console.log(err);
                    throw(err);                    
                }
            }
        
        return(oReplacementStore[replacementHTML]);
    }    

   /**
     * @function HOK_handleFileSttribute
     * 
     * handles <fileattribute></fileattribute> replacements
     * 
     * @param sAttribute <string> Attribute to Process
     * 
     * @return sValue <string> Value to Return
     */
    async function HOK_handleFileSttribute(sAttribute, sFilename){
        let sValue="";
        switch (sAttribute) {
            case "filename":
                sValue=sFilename;
                break;
        }
        return sValue;
    }

   /**
     * @function HOK_formatDate
     * 
     * handles <fileattribute></fileattribute> replacements
     * 
     * @param sInputHTML    <string>    HTML
     * @param sFilename     <string>    Name of target HTML file
     * 
     * @return sOutputHTML  <string>    resolved HTML
     */
    async function HOK_processFileAttribuites(sInputHTML, sFilename){
        const sOpenTag = "<fileattribute>";
        const sCloseTag = "</fileattribute>";
        let sOutputHTML = "";
        const start = sInputHTML.indexOf(sOpenTag);
        if (start > -1){
            const end = sInputHTML.indexOf(sCloseTag); 
            sOutputHTML += await sInputHTML.slice(0, start);  
            sOutputHTML += await HOK_handleFileSttribute(sInputHTML.slice(start+sOpenTag.length, end),sFilename);
            const newInputHTML = sInputHTML.slice(end+sCloseTag.length);
            if (newInputHTML.indexOf(sOpenTag) > -1){
                sOutputHTML += await HOK_processFileAttribuites(newInputHTML);
            } else {
                sOutputHTML += newInputHTML;
            }
        }else{
            sOutputHTML += sInputHTML;        
        }
        const start2 = sOutputHTML.indexOf(sOpenTag);
        if (start2 > -1){
            sOutputHTML = await HOK_processFileAttribuites(sOutputHTML);
        }
        return(sOutputHTML);
    }
    
    async function generateHTML(inputHTML,SourceBucket){
        var outputHTML = "";
        const start = inputHTML.indexOf("<part>");
        if (start > -1){
            const end = inputHTML.indexOf("</part>"); 
            outputHTML += await inputHTML.slice(0, start);  
            outputHTML += await getReplacementHTML(inputHTML.slice(start+6, end),SourceBucket);
            const newInputHTML = inputHTML.slice(end+7);
            if (newInputHTML.indexOf("<part") > -1){
                outputHTML += await generateHTML(newInputHTML,SourceBucket);
            } else {
                outputHTML += newInputHTML;
            }
        }else{
            outputHTML += inputHTML;        
        }
        const start2 = outputHTML.indexOf("<part>");
        if (start2 > -1){
            outputHTML = await generateHTML(outputHTML,SourceBucket);
        }
        return(outputHTML);
    }

    async function generateHTMLfromDB(inputHTML){
        let outputHTML = "";
        const start = inputHTML.indexOf("<dbpart>");
        if (start > -1){
            const end = inputHTML.indexOf("</dbpart>"); 
            outputHTML += await inputHTML.slice(0, start);  
            outputHTML += await getReplacementHTMLfromDB(inputHTML.slice(start+8, end));
            const newInputHTML = inputHTML.slice(end+9);
            if (newInputHTML.indexOf("<dbpart") > -1){
                outputHTML += await generateHTMLfromDB(newInputHTML);
            } else {
                outputHTML += newInputHTML;
            }
        }else{
            outputHTML += inputHTML;        
        }
        const start2 = outputHTML.indexOf("<dbpart>");
        if (start2 > -1){
            outputHTML = await generateHTMLfromDB(outputHTML);
        }
        return(outputHTML);
    }

    /**
     * Returns the nth occurence of a substring
     */
    async function HOK_getPosition(string, subString, index) {
        return string.split(subString, index).join(subString).length;
    }

    /**
     * Takes an object and an identifier. Returns string that is conten of object at indetifier.
     */
    async function HOK_process_dynamic_from_item(oItem, sCommand){
        let sResult = "";
        
        if(sCommand[0] =="{"){
            //If is object with instructions
            const oCommand=JSON.parse(sCommand);
            
                //If command is "limit"
                    if(oCommand.limit!=undefined){
                        let iTextLength = oCommand.limit;
                        if(oCommand.limitlow!=undefined){
                            iTextLength = (Math.random()*oCommand.limit)+oCommand.limitlow;                    
                        }
                        let iBaseLength = oItem[oCommand.field].S.length;
                        let sParen="";
                        if(iTextLength==0 || iTextLength>iBaseLength){iTextLength = iBaseLength;}else{sParen="..."}
                        sResult += await HOK_fixHtml(oItem[oCommand.field].S.slice(0,iTextLength)+sParen);            
                    } else if(oCommand.format!=undefined){
                //If command is format
                    if(oCommand.format=="date"){
                        sResult += await HOK_formatDate(oItem[oCommand.field].N,oCommand.locale);
                    } }else if(oCommand.divideattag!=undefined){
                //If command is divide
                        const sContentToDivide = oItem[oCommand.field].S;
                        
                        let iPositionStart = 0;
                        if(oCommand.startnumber!=undefined){
                            iPositionStart = await HOK_getPosition( sContentToDivide, oCommand.divideattag, oCommand.startnumber );
                        }
                        let iPositionEnd = oItem[oCommand.field].S.length;
                        if(oCommand.endnumber!=undefined){
                            iPositionEnd = await HOK_getPosition( sContentToDivide, oCommand.divideattag, oCommand.endnumber );
                        }
                        sResult += oItem[oCommand.field].S.slice(iPositionStart,iPositionEnd);
                    }
                } else {
            //If command is fieldname
                    if(oItem[sCommand].S!=undefined){sResult = oItem[sCommand].S;}
                    if(oItem[sCommand].N!=undefined){sResult = oItem[sCommand].N;}
                }
        
        return sResult;
    }

    /**
     * Handles "dbmultifileitem" tags 
     */
    async function generateHTMLfromMultiDynamic(inputHTML,oItem){
        let outputHTML = "";
        const start = inputHTML.indexOf("<dbmultifileitem>");
        if (start > -1){
            outputHTML += await inputHTML.slice(0, start);  

            const end = inputHTML.indexOf("</dbmultifileitem>");
            outputHTML += await HOK_process_dynamic_from_item(oItem,inputHTML.slice(start+("<dbmultifileitem>".length),end));

            outputHTML += await inputHTML.slice(end+("</dbmultifileitem>".length)); 
        }else{
            outputHTML += inputHTML;        
        }
        
        const start2 = outputHTML.indexOf("<dbmultifileitem>");
        if (start2 > -1){
            outputHTML = await generateHTMLfromMultiDynamic(outputHTML,oItem);
        }
        return(outputHTML);        
    }

    async function generateHTMLfromDBDynamic(inputHTML){
        let outputHTML = "";
        const start = inputHTML.indexOf("<dbmulti>");
        if (start > -1){
            const end = inputHTML.indexOf("</dbmulti>"); 
            outputHTML += await inputHTML.slice(0, start);  
            outputHTML += await processmulti(inputHTML.slice(start+9, end));
            const newInputHTML = inputHTML.slice(end+10);
            if (newInputHTML.indexOf("<dbmulti") > -1){
                outputHTML += await generateHTMLfromDB(newInputHTML);
            } else {
                outputHTML += newInputHTML;
            }
        }else{
            outputHTML += inputHTML;        
        }
        const start2 = outputHTML.indexOf("<dbmulti>");
        if (start2 > -1){
            outputHTML = await generateHTMLfromDB(outputHTML);
        }
        return(outputHTML);
    }

    async function processmulti(sReplacementHTML){
        let oReplacementHTML = JSON.parse(sReplacementHTML);

	    let oScanParams = {
			TableName:oReplacementHTML.table,
			FilterExpression:"",
			ExpressionAttributeNames:{},
			ExpressionAttributeValues:{}
		};
		for(let i=0;i<oReplacementHTML.filter.length;i++){
		    oScanParams.FilterExpression = oScanParams.FilterExpression + "#attr"+i+" = :val"+i;
		    const sKey = Object.keys(oReplacementHTML.filter[i])[0];
		    const oContent = oReplacementHTML.filter[i][sKey];
		    oScanParams.ExpressionAttributeNames["#attr"+i] = sKey; 
		    oScanParams.ExpressionAttributeValues[":val"+i] = oContent;
		}
        const aScanResult = await scanTable(ddb,oScanParams);

        let sResultHTML = "";

		for(let i=0;i<aScanResult.length;i++){
		    sResultHTML += await replaceWithDBItem(aScanResult[i],oReplacementHTML.template);
		}
        return (sResultHTML);
    }

    async function poplastfitting(a, target) {
        for(let i=a.length;i>=0;i--){
            if(a[i]==target){
                a.splice(i, 1); 
            }
        }
        return a;
    }
    
   /**
     * function HOK_fixHtml
     * 
     * closes open Tags
     * 
     * @param sHtml <string> HTML Fragment to fix
     * 
     * @return sReturn <string> Valid HTML
     */    
    async function HOK_fixHtml(sHtml){
        // cut unfinished (open) tags at end of string
            const iPosLastOpenTag = sHtml.lastIndexOf("<");
            const iPosLastCloseTag = sHtml.lastIndexOf(">");
            if (iPosLastOpenTag > iPosLastCloseTag){
                sHtml = sHtml.slice(0,iPosLastOpenTag);
            }
        
        //close open tags
            let aMatches = sHtml.match(/<\/?[a-z][^>]*>/ig);
            let aTags = [];        
            for(let i=0;i<aMatches.length;i++){
                //Analyze tag
                    //cut off end of Tag
                        const aMatchDetail = aMatches[i].split(" "); 
                        let sMatchDetail = aMatchDetail[0];
                        if(sMatchDetail[sMatchDetail.length-1]==">"){sMatchDetail = sMatchDetail.slice(0,sMatchDetail.length-1)}
                    //cut off beginnign of Tag
                        sMatchDetail = sMatchDetail.slice(1);
    
                    if( sMatchDetail[0] == "/" ){
                        sMatchDetail = sMatchDetail.slice(1);
                        aTags = await poplastfitting(aTags, sMatchDetail);
                    }else{
                        aTags.push(sMatchDetail);
                    }
            }
            for(let i=aTags.length-1; i>=0;i--){
                sHtml += "</"+aTags[i]+">";
            }
            
        return(sHtml);
    }    
    
   /**
     * function HOK_formatDate
     * 
     * @param sDate <string> Date to convert
     * 
     * @return sReturn <string> coverted date
     */
    async function HOK_formatDate(iDate,sLocale){
        if(iDate<1000000000000){iDate=iDate*1000}
        let date = new Date(iDate);
        let year = date.getFullYear();
        let month = date.getMonth()+1;
        let dt = date.getDate();

        if (dt < 10) {
        dt = '0' + dt;
        }
        if (month < 10) {
        month = '0' + month;
        }
        let retval = month + '/' + dt + '/' + year;
        if(sLocale=="de"){
            retval = dt+'.' + month + '.'+year;
        }
        return retval;
    }
    
    async function replaceWithDBItem(oDBItem,inputHTML){
        let outputHTML = "";
        const start = inputHTML.indexOf("<dbitem>");
        if (start > -1){
            const end = inputHTML.indexOf("</dbitem>"); 
            outputHTML += await inputHTML.slice(0, start);  
            const sDBItem = inputHTML.slice(start+8, end);
            if(sDBItem[0]=="{"){
                const oDBItem2 = JSON.parse(sDBItem);
                let iTextLength = 0;
                if(oDBItem2.limit!=undefined){
                    iTextLength = oDBItem2.limit;
                    if(oDBItem2.limitlow!=undefined){
                        iTextLength = (Math.random()*oDBItem2.limit)+oDBItem2.limitlow;                    
                    }
                    let iBaseLength = oDBItem[oDBItem2.field].S;
                    let sParen="";
                    if(iTextLength==0 || iTextLength>iBaseLength){iTextLength = iBaseLength;}else{sParen="..."}
                    outputHTML += await HOK_fixHtml(oDBItem[oDBItem2.field].S.slice(0,iTextLength)+sParen);
                } else if(oDBItem2.format!=undefined){
                    if(oDBItem2.format=="date"){
                        outputHTML += await HOK_formatDate(oDBItem[oDBItem2.field].N,oDBItem2.locale);
                    }
                }                
            } else{
                if(oDBItem[sDBItem].S!=undefined){outputHTML += oDBItem[sDBItem].S;}
                if(oDBItem[sDBItem].N!=undefined){outputHTML += oDBItem[sDBItem].N;}
            }
            const newInputHTML = inputHTML.slice(end+9);
            if (newInputHTML.indexOf("<dbitem") > -1){
                outputHTML += await replaceWithDBItem(oDBItem,newInputHTML);
            } else {
                outputHTML += newInputHTML;
            }
        }else{
            outputHTML += inputHTML;        
        }
        const start2 = outputHTML.indexOf("<dbpart>");
        if (start2 > -1){
            outputHTML = await generateHTMLfromDB(outputHTML);
        }
        return(outputHTML);
    }

    async function removeHTMLComments(sHTML){
        const start = sHTML.indexOf("<!--");
        if (start > -1){
            let end = sHTML.indexOf("-->",start); 
            let outputHTML = await sHTML.slice(0, start);
            outputHTML += await sHTML.slice((end+3));
            sHTML = await removeHTMLComments(outputHTML);
        }
        return sHTML;
    }

    async function removeCSSComments(sHTML){
        let start = sHTML.indexOf("/*");
        if (start > -1){
            let end = sHTML.indexOf("*/",start); 
            let outputHTML = await sHTML.slice(0, start);
            outputHTML += await sHTML.slice((end+2));
            sHTML = await removeCSSComments(outputHTML);
        }
        return sHTML;
    }

    async function minifyCSS(sHTML,iLastIndex){
        let start = sHTML.indexOf("<style>",iLastIndex);
        if (start > -1){
            let end = sHTML.indexOf("</style>",start); 
            let outputHTML = await sHTML.slice(0, start+7);
            outputHTML += await removeCSSComments(sHTML.slice(start+7, end));
            outputHTML += await sHTML.slice((end));
            sHTML = await minifyCSS(outputHTML,end+8);
        }
        return sHTML;
    }

    async function removeWhitespaces(inputHTML){
        return inputHTML.replace(/\s+/g, ' ');
    }
    
    async function removeJSComments(sHTML,iLastIndex=0){
        let start = sHTML.indexOf("/*",iLastIndex);
        if (start > -1){
            let end = sHTML.indexOf("*/",start);
            let sHTML2 = sHTML.slice(0, start);
            sHTML2 += sHTML.slice(end+2);
            sHTML = await removeJSComments(sHTML2);
        }
        
        start = sHTML.indexOf("//",iLastIndex);
        if(sHTML[start-1]==" "){
            if (start > -1){
                let end = sHTML.indexOf("\n",start);
                let sHTML2 = sHTML.slice(0, start);
                sHTML2 += sHTML.slice(end+2);
                sHTML = await removeJSComments(sHTML2);
            }
        }
        return sHTML;
    }

    async function minifyAll(sHTML,iLastIndex=0){
        let start = sHTML.indexOf("<script>",iLastIndex);
        if (start > -1){
            let end = sHTML.indexOf("</script>",start); 
            let outputHTML = await removeWhitespaces(sHTML.slice(0, start));
            outputHTML += await removeJSComments(sHTML.slice(start,end+9));
            let iNewStart = outputHTML.length;
            outputHTML += sHTML.slice(end+9);
            if(iNewStart<outputHTML.length){
                sHTML = await minifyAll(outputHTML,iNewStart);                
            }
            sHTML = outputHTML;
        } else {
            sHTML = sHTML.slice(0,iLastIndex) + await removeWhitespaces(sHTML.slice(iLastIndex));
        }
        return sHTML;
    }
    
    async function minifyHTML(sHTML){
        //Step 1 : Remove HTML Comments
            sHTML = await removeHTMLComments(sHTML);
        //Step 2 : Process CSS
            sHTML = await minifyCSS(sHTML,0);
        //Step 3 : Process anything but JS
            sHTML = await minifyAll(sHTML,0);
        //...
        return(sHTML);
    }
    
    async function scanTable(documentClient, params) {
        const scanResults = [];
        let items = null;
        do{
            items =  await documentClient.scan(params).promise();
            items.Items.forEach((item) => scanResults.push(item));
            params.ExclusiveStartKey  = items.LastEvaluatedKey;
        }while(typeof items.LastEvaluatedKey !== "undefined");
        return scanResults;
    }

    async function writePartUseage(aParts, sSource, sSrcKey=null){
                
		const params = {
			TableName:htmlPartElementTable,
			FilterExpression: '#attr = :val',
			ExpressionAttributeNames:{
		    	"#attr": "source"
			},
			ExpressionAttributeValues: { 
				':val': {"S":sSource}
			}		
		};
		const oData = await scanTable(ddb,params);
        //Add parts that are missing in ddb
    	for (let i=0; i<aParts.length; i++){
    	    let bExists = false;
    	    for(let j=0; j<oData.length ;j++){
    	        if(oData[j].part.S==aParts[i]){
    	            bExists = true;
    	            j=oData.length;
    	        }
    	    }
    	    //if existing: skip 
    	    //else write to target DynamoDB       
            if(!bExists){
                let params2 = {
                  TableName: htmlPartElementTable,
                  Item: {
                      "source":{"S":sSource},
                      "part":{"S":aParts[i]}
                  }
                };   
                if(sSrcKey!=null) {
                    params2.Item.template = {"S":sSrcKey};
                }
                await ddb.putItem(params2, function(err, data) {
                  if (err) {
                    console.warn("Error", err);
                  }
                }).promise();   
                
                oData.push(params2.Item);
            }    	    
        }

        //Remove parts not used anmyore in ddb
	    for(let j=0; j<oData.length ;j++){
	       	let bExists = false;
	       	for (let i=0; i<aParts.length; i++){
    	        if(oData[j].part.S==aParts[i]){
    	            bExists = true;
    	            i=aParts.length;
    	        }
	       	}
            if(!bExists){
                const params3 = {
        			TableName:htmlPartElementTable,
        			"Key": oData[j]	
        		};
                await ddb.deleteItem(params3).promise();                    
            }
	    }        
        
    }
    
    /**
     * function HOK_handlemultifile
     * 
     * Triggers the update of a certain file from the "website" folder
     * 
     * @param sHTML         <string>                    XML entity "<dbmultifile>...</dbmultifile>" to process (resolve)
     * @param sFilename     <string>
     * @param sOriginBucket <string>                    Name of bucket of origin file
     * @param sOriginKey    <string>                    Name of origin file with path. Must be iunside sOriginBucket. When processing a dbmultifile, this is the template.
     * 
     * @return  true - if successfull
     *          false - if html doesn't start with <dbmultifile>
     */    
    async function HOK_handlemultifile(sHTML,sFilename,sOriginBucket,sOriginKey){
        if(!sHTML.startsWith("<dbmultifile>")){return false;}
        
        const sReplacementHTML = sHTML.slice(13,sHTML.indexOf("</dbmultifile>"));
        const oReplacementHTML = JSON.parse(sReplacementHTML);

	    let oScanParams = {
			TableName:oReplacementHTML.table,
			FilterExpression:"",
			ExpressionAttributeNames:{},
			ExpressionAttributeValues:{}
		};
		for(let i=0;i<oReplacementHTML.filter.length;i++){
		    oScanParams.FilterExpression = oScanParams.FilterExpression + "#attr"+i+" = :val"+i;
		    const sKey = Object.keys(oReplacementHTML.filter[i])[0];
		    const oContent = oReplacementHTML.filter[i][sKey];
		    oScanParams.ExpressionAttributeNames["#attr"+i] = sKey; 
		    oScanParams.ExpressionAttributeValues[":val"+i] = oContent;
		}
        const aScanResult = await scanTable(ddb,oScanParams);

        for(let i=0; i<aScanResult.length; i++){
            //Create Filename
                let sSuffix ="";
                if(aScanResult[i][oReplacementHTML.filenamesuffix].S!=undefined){sSuffix = aScanResult[i][oReplacementHTML.filenamesuffix].S} else
                if(aScanResult[i][oReplacementHTML.filenamesuffix].N!=undefined){sSuffix = aScanResult[i][oReplacementHTML.filenamesuffix].N}
                const iFileSuffixStart = sFilename.lastIndexOf(".");
                const sFilenameNew = sFilename.slice(0,iFileSuffixStart) + "-"+ sSuffix + sFilename.slice(iFileSuffixStart);
            //Generate File
                await HOK_updateWebsiteFile(sFilenameNew,sOriginBucket,sOriginKey,true,aScanResult[i]);
        }
        return true;
    }
    
    /**
     * function HOK_updateWebsiteFile
     * 
     * Triggers the update of a certain file from the "website" folder
     * 
     * @param sFilename         <string>                    Name of target file
     * @param sOriginBucket     <string>                    Name of bucket of origin file
     * @param sOriginKey        <string>                    Name of origin file with path. Must be iunside sOriginBucket. When processing a dbmultifile, this is the template.
     * @param bSkipMultiCheck   <bool>      Default: false  Set true, if you don't want to process multiple, subsecuent files 
     * @param oItem             <object>    Default: null   Object of Item ro process (rather than read it from file)
     * 
     * @return always null
     */
    async function HOK_updateWebsiteFile(sFilename, sOriginBucket, sOriginKey, bSkipMultiCheck=false, oItem=null){

        const sFileContent = (await s3.getObject({ Bucket: sOriginBucket, Key: sOriginKey }).promise()).Body.toString('utf-8');

        if(!bSkipMultiCheck){
            if(await HOK_handlemultifile(sFileContent,sFilename,sOriginBucket,sOriginKey)){return null}
        }
        
        aReplacementShortList = [];         

        let newHTML = (await generateHTMLfromDB((await generateHTML( await HOK_processFileAttribuites(sFileContent, sFilename), sOriginBucket ))));
        if(oItem != null){
            newHTML = newHTML.slice(newHTML.indexOf("</dbmultifile>")+14);
            newHTML = (await generateHTMLfromMultiDynamic(newHTML,oItem));
        }
        newHTML = (await generateHTMLfromDBDynamic(newHTML));

        newHTML = (await minifyHTML(newHTML));
        await s3.putObject({ 
            Body: newHTML, 
            Bucket: sDestBucket, 
            Key: sFilename, 
            ACL: 'public-read',  
            ContentType: 'text/html'
        }).promise();
        await writePartUseage(aReplacementShortList, sFilename, sOriginKey); 

        return null;
    }
    
console.log("event:" ,JSON.stringify(event));
    
//Main
    try{
        for (var record of event.Records) {
            if(record.eventSource=="aws:dynamodb"){ //In case of: Dynamo DB 
                if(record.eventName != 'REMOVE'){ //In case of Remove Item
            		const params = {
            			TableName:htmlPartElementTable,
            			FilterExpression: '#attr = :val',
            			ExpressionAttributeNames:{
            		    	"#attr": "part"
            			},
            			ExpressionAttributeValues: { 
            				':val': {"S":record.dynamodb.NewImage.content_id.S}
            			}		
            		};
            		const aData = await scanTable(ddb,params);
            		
                    for(let i=0;i<aData.length;i++){
                        await HOK_updateWebsiteFile(aData[i].template.S.slice(8), sOriginBucket, aData[i].template.S);
                    } 
                }
            }else{ // In case of S3
                const sFilekeyFull = record.s3.object.key;
                if(sFilekeyFull.indexOf(".") != -1){ //If not a folder
                    if (sFilekeyFull.localeCompare("website/") > 0) {  // If file is from folder "website"                    
                        const sFilename = sFilekeyFull.slice("website/".length);                
                        await HOK_updateWebsiteFile(sFilename, record.s3.bucket.name, sFilekeyFull);
                    } else if (sFilekeyFull.localeCompare("part/") > 0) { // If file is from folder "part"
                        const sFilename = sFilekeyFull.slice("part/".length);                    
                		const params = {
                			TableName:htmlPartElementTable,
                			FilterExpression: '#attr = :val',
                			ExpressionAttributeNames:{
                		    	"#attr": "part"
                			},
                			ExpressionAttributeValues: { 
                				':val': {"S":sFilename}
                			}		
                		};
                		const aData = await scanTable(ddb,params);
                        for(let i=0;i<aData.length;i++){
                            await HOK_updateWebsiteFile(aData[i].template.S.slice(8), record.s3.bucket.name, aData[i].template.S);
                        }
                        
                    }
                }

            }
        }   
    } catch(err){throw(err);}
    return 0;
};