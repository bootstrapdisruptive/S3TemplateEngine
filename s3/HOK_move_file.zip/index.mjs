'use strict';

/** Map environment variables */
const sRegion = process.env.AWS_REGION;
const oConfig = JSON.parse(process.env.config);

/** Prepare AWS objects */
    import { S3Client, DeleteObjectCommand, CopyObjectCommand } from "@aws-sdk/client-s3";
    const s3 = new S3Client({region: sRegion});

/** Main handler. 
  * Lamnbda builds a new environment and invokes new calls into htis environment
  * for a certain, not predictable, time. In that case everything outside of
  * this handler will persist. This is OK for cosntants, but ends up 
  * unpredictable for gobal variables and (under certain cirsumstances) for
  * variables in helper functions.
  * Therefore, helper functions are part of this main handler, so they are
  * initialized freshly and behave predictable on each call of the lambda.
  */    
export const handler = async (event, context) => {
  console.log(JSON.stringify(event));
  try {
    for (let record of event.Records) {
      const iStart = record.s3.bucket.name.indexOf('-') + 1;
      const iEnd = record.s3.bucket.name.indexOf('-', iStart);
      const sVariant = record.s3.bucket.name.substring(iStart, iEnd);
      const aLangs = oConfig[sVariant];
      for (let i = 0; i < aLangs.length; i++) {
        const aLang = aLangs[i];
        const sBucket = aLang[Object.keys(aLang)[0]].bucket;
        if (record.eventName.startsWith('ObjectRemoved')) {
          let params = {
            Bucket: sBucket,
            Key: record.s3.object.key
          };
          await s3.send(new DeleteObjectCommand(params));
        } else {
          let params = {
            CopySource: record.s3.bucket.name + '/' + record.s3.object.key,
            Bucket: sBucket,
            Key: record.s3.object.key,
            ACL: 'public-read'
          };
          await s3.send(new CopyObjectCommand(params));
        }
      }
    }
  } catch (err) {
    throw (err);
  }
  return 0;
};
